# Starter Repository for Assignment

You are required to build your folder structures for your project.
.
├── index.js # Main application entry point
├── src
│ ├── app.js # Express app configuration and middleware
│ ├── config # Database setup scripts
│ │ ├── createSchema.js
│ │ └── initTables.js
│ ├── controller # Business logic (request/response handling)
│ │ ├── challengeController.js
│ │ ├── completionController.js
│ │ └── userController.js
│ ├── models # Database-facing logic (SQL queries)
│ │ ├── user.js
│ │ ├── userCompletion.js
│ │ └── wellnessChallenge.js
│ ├── routes # API route definitions
│ │ ├── challengeRoutes.js
│ │ └── userRoutes.js
│ └── services # Database connection pool
│ └── db.js
├── .env # Environment variables (must be created)
├── .gitignore
├── package.json
└── README.md
