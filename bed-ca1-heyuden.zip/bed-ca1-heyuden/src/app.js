const express = require("express");
const app = express();

// Middleware to parse JSON request bodies
app.use(express.json());

// Middleware to parse URL-encoded request bodies
app.use(express.urlencoded({ extended: true }));

// --- Define Routes ---
const userRoutes = require("./routes/userRoutes");
const challengeRoutes = require("./routes/challengeRoutes");
const shopRoutes = require("./routes/shopRoutes");
const bossRoutes = require("./routes/bossRoutes");
const inventoryRoutes = require("./routes/inventoryRoutes");
// We will add the completion routes later, nested under challenges

app.use("/users", userRoutes);
app.use("/challenges", challengeRoutes);
app.use("/shop", shopRoutes);
app.use("/boss", bossRoutes);
app.use("/inventory", inventoryRoutes)

// --- Basic Error Handling Middleware ---
// This middleware will catch errors passed by next(error)
app.use((error, req, res, next) => {
  console.error(error.stack); // Log the error stack for debugging
  const statusCode = error.statusCode || 500;
  const message = error.message || "Something went wrong on the server";
  res.status(statusCode).json({ message: message });
});

// Module exports the configured Express app
module.exports = app;
