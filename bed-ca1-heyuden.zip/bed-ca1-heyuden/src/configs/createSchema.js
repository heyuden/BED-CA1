// This script is used to create the database (schema) if it doesn't exist.
// It connects to MySQL without specifying a database.

// Load environment variables from the root .env file
require("dotenv").config();
const mysql = require("mysql2");

const dbName = process.env.DB_NAME;

if (!dbName) {
  console.error("Error: DB_NAME is not defined in your .env file.");
  console.log("Please define DB_NAME in the .env file at the project root.");
  process.exit(1); // Exit script with an error
}

// Create a connection config *without* the database name
const connectionConfig = {
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  port: process.env.DB_PORT,
};

const connection = mysql.createConnection(connectionConfig);

// Connect to the MySQL server
connection.connect((err) => {
  if (err) {
    console.error("Error connecting to MySQL server:", err.stack);
    return;
  }
  console.log("Successfully connected to MySQL server.");

  const query = `CREATE DATABASE IF NOT EXISTS \`${dbName}\``;

  // Execute the create database query
  connection.query(query, (err, result) => {
    if (err) {
      console.error(`Error creating database ${dbName}:`, err);
      connection.end(); // Close connection on error
      return;
    }

    if (result.warningStatus === 0) {
      console.log(`Database '${dbName}' was created successfully.`);
    } else {
      console.log(`Database '${dbName}' already exists.`);
    }

    connection.end(); // Close connection on success
  });
});
