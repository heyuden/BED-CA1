// This script connects to the database (defined in db.js)
// and creates the tables and inserts initial data.

const db = require("../services/db"); // Uses the configured pool from db.js
// the table with foreign keys can be dropped first
//tables with primary keys used in other tables (foreign keys) should be created first
//insert records into tables with primary keys that other tables reference to
// Array of SQL queries to run

const sqlQueries = [`
  -- Drop tables
  DROP TABLE IF EXISTS UserInventory;
  DROP TABLE IF EXISTS UserCompletion;
  DROP TABLE IF EXISTS ShopItem;
  DROP TABLE IF EXISTS WellnessChallenge;
  DROP TABLE IF EXISTS Boss;
  DROP TABLE IF EXISTS User;

  -- 1. Create User (Added HP and Defense)
  CREATE TABLE User (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,
    points INT DEFAULT 0,
    level INT DEFAULT 1,
    xp INT DEFAULT 0,
    max_hp INT DEFAULT 100,
    current_hp INT DEFAULT 100,
    defense INT DEFAULT 0
  );

  -- 2. Create Challenges
  CREATE TABLE WellnessChallenge (
    challenge_id INT AUTO_INCREMENT PRIMARY KEY,
    creator_id INT NOT NULL,
    description TEXT NOT NULL,
    points INT NOT NULL,
    xp_reward INT DEFAULT 50,
    FOREIGN KEY (creator_id) REFERENCES User(user_id) ON DELETE CASCADE
  );

  -- 3. Create Completions
  CREATE TABLE UserCompletion (
    completion_id INT AUTO_INCREMENT PRIMARY KEY,
    challenge_id INT NOT NULL,
    user_id INT NOT NULL,
    details TEXT,
    completed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (challenge_id) REFERENCES WellnessChallenge(challenge_id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES User(user_id) ON DELETE CASCADE
  );

  -- 4. Create Shop Items
  CREATE TABLE ShopItem (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    type ENUM('weapon', 'armor', 'potion') NOT NULL,
    power_value INT NOT NULL,
    cost INT NOT NULL
  );

  -- 5. Create Inventory
  CREATE TABLE UserInventory (
    inventory_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    item_id INT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES User(user_id) ON DELETE CASCADE,
    FOREIGN KEY (item_id) REFERENCES ShopItem(item_id) ON DELETE CASCADE
  );

  -- 6. Create Boss (Added current_hp)
  CREATE TABLE Boss (
    boss_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    total_hp INT NOT NULL,
    current_hp INT NOT NULL,
    attack_power INT NOT NULL
  );

  -- Seed Data: Users
  INSERT INTO User (username, points, level, current_hp, defense) VALUES
  ('Sellie', 100, 2, 100, 5),
  ('Armageddon', 150, 3, 100, 10),
  ('Steve', 100, 50, 2, 200),
  ('Ash', 125, 70, 1, 100);

  -- Seed Data: Challenges
  INSERT INTO WellnessChallenge (creator_id, description, points) VALUES
  (1, 'Run 5km', 50),
  (1, 'Drink Water', 20),
  (3, 'Meditate for 20 minutes', 40),
  (1, 'Do 30 push-ups', 60),
  (2, 'Sleep at least 8 hours', 50);

  -- Seed Data: Shop (Weapons = Dmg, Armor = Def, Potion = Heal)
  INSERT INTO ShopItem (name, type, power_value, cost) VALUES
  ('Iron Sword', 'weapon', 20, 50),
  ('Steel Armor', 'armor', 30, 40),
  ('Star Rail Saber', 'weapon', 75, 150),
  ('Quantum Shield', 'armor', 60, 70),
  ('Excalibur', 'weapon', 45, 100),
  ('Netherite Armor',  'armor', 90, 90),
  ('Healing Potion', 'potion', 50, 15);

  -- Seed Data: Boss
  INSERT INTO Boss (name, total_hp, current_hp, attack_power) VALUES
  ('Doomsday Beast', 750, 750, 35),
  ('Shadow Beast', 1000, 1000, 40),
  ('Cocolia', 2000, 2000, 50);
`
];

// Function to run queries sequentially
function runQueries(queries, callback) {
  // if no more queries, we're done
  if (queries.length === 0) {
    return callback();
  }

  // Get the next query
  const query = queries.shift();

  if (!query) {
    return runQueries(queries, callback); // Skip if empty
  }

  // Run the query
  db.query(query, (err, result) => {
    if (err) {
      return callback(err, query); // Pass error and query
    }

    console.log(`Successfully executed: ${query.substring(0, 50)}...`);

    // Run the next query
    runQueries(queries, callback);
  });
}

console.log("Running database table initialization...");

// Start running the queries
runQueries(sqlQueries, (err, query) => {
  if (err) {
    console.error("Error executing query:", query);
    console.error(err);
  } else {
    console.log("All tables and data initialized successfully.");
  }
  // Close the database pool
  db.end();
});
