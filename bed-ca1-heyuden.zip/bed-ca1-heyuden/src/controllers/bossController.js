const bossModel = require("../models/boss");

exports.getBossInfo = (req, res, next) => {
    bossModel.findById(req.params.boss_id, (err, result) => {
        if (err) return next(err);
        res.status(200).json(result);
    });
}

exports.startBossFight = (req, res, next) => {
    const { user_id } = req.body;
    if (!user_id) return res.status(400).json({ message: "Missing user_id" });

    bossModel.fight(user_id, req.params.boss_id, (err, result) => {
        if (err) {
            if (err.type === "user_dead") return res.status(400).json({ message: "You are dead! Heal first." });
            if (err.type === "boss_dead") return res.status(400).json({ message: "Boss is already dead!" });
            err.statusCode = 500;
            return next(err);
        }
        res.status(200).json(result);
    });
};

exports.usePotion = (req, res, next) => {
    const { user_id } = req.body;
    if (!user_id) return res.status(400).json({ message: "Missing user_id" });

    bossModel.heal(user_id, (err, result) => {
        if (err) {
            if (err.type === "no_potion") return res.status(400).json({ message: "No potions in inventory!" });
            err.statusCode = 500;
            return next(err);
        }
        res.status(200).json(result);
    });
};