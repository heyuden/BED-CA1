const challengeModel = require("../models/wellnessChallenge");
const completionModel = require("../models/userCompletion");

// Controller to create a new challenge
// Handles POST /challenges
exports.createNewChallenge = (req, res, next) => {
  const { description, user_id, points } = req.body;

  // Error Handling: Missing fields
  if (!description || !user_id || points === undefined) {
    return res
      .status(400)
      .json({ message: "Missing description, user_id, or points" });
  }

  const challengeData = {
    creator_id: user_id,
    description: description,
    points: points,
  };

  challengeModel.create(challengeData, (err, result) => {
    if (err) {
      // DEBUG: Log the specific error
      console.error("Error creating challenge:", err);
      err.statusCode = 500;
      return next(err);
    }
    // Success: Return the newly created challenge
    res.status(201).json(result);
  });
};

// Controller to get all challenges
// Handles GET /challenges
exports.getAllChallenges = (req, res, next) => {
  challengeModel.findAll((err, results) => {
    if (err) {
      // DEBUG: Log the specific error
      console.error("Error getting all challenges:", err);
      err.statusCode = 500;
      return next(err);
    }
    res.status(200).json(results);
  });
};

// Controller to delete a challenge
// Handles DELETE /challenges/:challenge_id
exports.deleteChallengeById = (req, res, next) => {
  const challengeId = req.params.challenge_id;

  // first ask the completionModel to delete all records 
  // where challenge_id matches the one we want to remove.
  //uses challengeId to connect between challenge and completion
  completionModel.deleteByChallengeId(
    challengeId,
    (err, deleteCompletionsResult) => {
      if (err) {
        // DEBUG: Log the specific error
        console.error("Error deleting associated completions:", err);
        err.statusCode = 500;
        return next(err);
      }

      // Now, delete the challenge itself
      //uses challengeId to connect between challenge and completion
      challengeModel.delete(challengeId, (err, deleteChallengeResult) => {
        if (err) {
          // Check for "not_found" error from model
          if (err.type === "not_found") {
            return res.status(404).json({ message: "Challenge not found" });
          }
          // DEBUG: Log the specific error
          console.error("Error deleting challenge:", err);
          err.statusCode = 500;
          return next(err);
        }
        // Success: Return no content
        res.status(204).end(); // .end() is needed for 204
      });
    }
  );
};

// Controller to update a challenge
// Handles PUT /challenges/:challenge_id
exports.updateChallengeById = (req, res, next) => {
  const challengeId = req.params.challenge_id;

  // Map 'question' to 'description' and use 'user_id' as creator_id.
  const { question, description, points, user_id } = req.body;

  // Use 'description' if provided, fall back to 'question'
  const challengeDescription = description || question;

  // Error Handling: Missing fields
  if (!challengeDescription || points === undefined || !user_id) {
    return res
      .status(400)
      .json({ message: "Missing challenge description, points, or user_id" });
  }

  const challengeData = {
    description: challengeDescription,
    points: points,
    creator_id: user_id, // This is used to verify ownership
  };

  challengeModel.update(challengeId, challengeData, (err, updatedChallenge) => {
    if (err) {
      // Check for specific model errors
      if (err.type === "not_found") {
        return res.status(404).json({ message: "Challenge not found" });
      }
      if (err.type === "forbidden") {
        return res
          .status(403)
          .json({ message: "Forbidden: You are not the owner" });
      }
      // DEBUG: Log the specific error
      console.error("Error updating challenge:", err);
      err.statusCode = 500;
      return next(err);
    }
    // Success: Return the updated challenge
    res.status(200).json(updatedChallenge);
  });
};
