const completionModel = require("../models/userCompletion");
const userModel = require("../models/user");
const challengeModel = require("../models/wellnessChallenge");

// Controller to create a new completion
// Handles POST /challenges/:challenge_id/completions
exports.createCompletion = (req, res, next) => {
  const challengeId = req.params.challenge_id;
  const { user_id, details } = req.body;

  // Error Handling: Missing user_id
  if (!user_id) {
    return res.status(400).json({ message: "Missing user_id" });
  }

  // We must check if BOTH the user and challenge exist.
  // This is a "callback-hell" situation, but required by the brief (no promises).

  // 1. Check if user exists
  userModel.findById(user_id, (err, user) => {
    if (err) {
      err.statusCode = 500;
      return next(err);
    }
    // Error Handling: User not found
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // 2. User exists, now check if challenge exists
    challengeModel.findById(challengeId, (err, challenge) => {
      if (err) {
        err.statusCode = 500;
        return next(err);
      }
      // Error Handling: Challenge not found
      if (!challenge) {
        return res.status(404).json({ message: "Challenge not found" });
      }

      // 3. Both exist, create the completion record
      const completionData = {
        challenge_id: challengeId,
        user_id: user_id,
        details: details || null, // details is optional
      };

      completionModel.create(completionData, (err, result) => {
        if (err) {
          err.statusCode = 500;
          return next(err);
        }

        // 4. Completion created, now award points (as per brief)
        const pointsToAward = challenge.points;
        completionModel.awardPoints(
          user_id,
          pointsToAward,
          (err, pointResult) => {
            if (err) {
              // Log the error but don't fail the request,
              // as the completion was already created.
              console.error("Failed to award points:", err);
            }

            // 5. Fetch the new completion record to return to user
            completionModel.findById(result.insertId, (err, newCompletion) => {
              if (err) {
                err.statusCode = 500;
                return next(err);
              }
              // Rename for response consistency with brief
              const response = {
                completion_id: newCompletion.completion_id,
                challenge_id: newCompletion.challenge_id,
                user_id: newCompletion.user_id,
                details: newCompletion.details,
              };
              res.status(201).json(response);
            });
          }
        );
      });
    });
  });
};

// Controller to get completions for a challenge
// Handles GET /challenges/:challenge_id/completions
exports.getCompletionsByChallengeId = (req, res, next) => {
  const challengeId = req.params.challenge_id;

  // First, check if the challenge exists to give a proper 404
  challengeModel.findById(challengeId, (err, challenge) => {
    if (err) {
      err.statusCode = 500;
      return next(err);
    }
    // Error Handling: Challenge not found
    if (!challenge) {
      return res.status(404).json({ message: "Challenge not found" });
    }

    // Challenge exists, now find its completions
    completionModel.findByChallengeId(challengeId, (err, completions) => {
      if (err) {
        err.statusCode = 500;
        return next(err);
      }

      // Error Handling: No attempts for this challenge
      if (completions.length === 0) {
        return res
          .status(404)
          .json({ message: "Challenge has no user attempts" });
      }

      // Format response as per brief (only user_id and details)
      const response = completions.map((comp) => ({
        user_id: comp.user_id,
        details: comp.details,
      }));

      res.status(200).json(response);
    });
  });
};
