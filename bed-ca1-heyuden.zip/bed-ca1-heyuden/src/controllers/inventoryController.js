const inventoryModel = require("../models/inventory");

exports.getUserInventory = (req, res, next) => {
    // 1. Log to console so we know the request reached here
    console.log("Inventory Controller hit for User ID:", req.params.user_id);

    // 2. Call the model
    inventoryModel.findByUserId(req.params.user_id, (err, results) => {
        if (err) {
            console.error("Database Error:", err);
            return res.status(500).json({ message: "Error fetching inventory" });
        }
        
        // 3. Return the results (even if empty array)
        res.status(200).json(results);
    });
};