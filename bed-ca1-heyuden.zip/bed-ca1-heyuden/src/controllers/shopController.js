const shopModel = require("../models/shopItem");

exports.getAllItems = (req, res, next) => {
  shopModel.findAll((err, results) => {
    if (err) {
        err.statusCode = 500;
        return next(err);
    }
    res.status(200).json(results);
  });
};

exports.buyItem = (req, res, next) => {
  const { user_id, item_id } = req.body;

  if (!user_id || !item_id) {
    return res.status(400).json({ message: "Missing user_id or item_id" });
  }

  shopModel.purchase(user_id, item_id, (err, result) => {
    if (err) {
      if (err.type === "insufficient_funds") return res.status(400).json({ message: "Not enough points!" });
      if (err.type === "user_not_found") return res.status(404).json({ message: "User not found" });
      if (err.type === "item_not_found") return res.status(404).json({ message: "Item not found" });
      
      err.statusCode = 500;
      return next(err);
    }
    res.status(201).json(result);
  });
};