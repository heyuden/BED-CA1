const userModel = require("../models/user");

// Controller to create a new user
// Handles POST /users
exports.createNewUser = (req, res, next) => {
  const { username } = req.body;

  // Error Handling: Missing username
  if (!username) {
    return res.status(400).json({ message: "Missing username" });
  }

  // Call the model function
  userModel.create(username, (err, result) => {
    if (err) {
      // DEBUG: Log the specific error
      console.error("Error creating user:", err);

      // Check for duplicate username error
      if (err.type === "conflict") {
        return res
          .status(409)
          .json({ message: "Username already associated with another user" });
      }

      // Pass other errors to the global error handler
      err.statusCode = 500;
      return next(err); // This will send the "Something went wrong" message
    }
    // Success: Return the newly created user info
    res.status(201).json(result);
  });
};

// Controller to get all users
// Handles GET /users
exports.getAllUsers = (req, res, next) => {
  userModel.findAll((err, results) => {
    if (err) {
      err.statusCode = 500;
      return next(err); // Pass error to global handler
    }
    res.status(200).json(results);
  });
};

// Controller to get a user by their ID
// Handles GET /users/:user_id
exports.getUserById = (req, res, next) => {
  const userId = req.params.user_id;

  userModel.findById(userId, (err, user) => {
    if (err) {
      // Check for "not_found" error from model
      if (err.type === "not_found") {
        return res.status(440).json({ message: "User not found" });
      }
      // Pass other errors to global handler
      err.statusCode = 500;
      return next(err);
    }
    // Success: Return the found user
    res.status(200).json(user);
  });
};

// Controller to update a user
// Handles PUT /users/:user_id
exports.updateUserById = (req, res, next) => {
  const userId = req.params.user_id;
  const { username, points } = req.body;

  // Error Handling: Missing fields
  if (username === undefined || points === undefined) {
    return res.status(400).json({ message: "Missing username or points" });
  }

  const userData = { username, points };

  userModel.update(userId, userData, (err, updatedUser) => {
    if (err) {
      // Check for specific model errors
      if (err.type === "not_found") {
        return res.status(404).json({ message: "User not found" });
      }
      if (err.type === "conflict") {
        return res
          .status(409)
          .json({ message: "Username already associated with another user" });
      }
      // Pass other errors to global handler
      err.statusCode = 500;
      return next(err);
    }
    // Success: Return the updated user
    res.status(200).json(updatedUser);
  });
};
