const db = require("../services/db");

const Boss = {
  findById: (bossId, callback) => {
    const query = "SELECT * FROM Boss WHERE boss_id = ?";
    db.query(query, [bossId], (err, results) => {
      if (err) return callback(err, null);
      if (results.length === 0) return callback({ type: "not_found" }, null);
      callback(null, results[0]);
    });
  },

  // --- TURN BASED FIGHT ---
  fight: (userId, bossId, callback) => {
    // 1. Get User Stats + Equipment
    const userStatsQuery = `
      SELECT u.current_hp, u.defense, 
      IFNULL(SUM(CASE WHEN s.type = 'weapon' THEN s.power_value ELSE 0 END), 0) as weapon_dmg,
      IFNULL(SUM(CASE WHEN s.type = 'armor' THEN s.power_value ELSE 0 END), 0) as armor_def
      FROM User u
      LEFT JOIN UserInventory ui ON u.user_id = ui.user_id
      LEFT JOIN ShopItem s ON ui.item_id = s.item_id
      WHERE u.user_id = ?
      GROUP BY u.user_id
    `;

    db.query(userStatsQuery, [userId], (err, userRes) => {
      if (err) return callback(err, null);
      if (userRes.length === 0) return callback({ type: "user_not_found" }, null);
      
      const user = userRes[0];
      if (user.current_hp <= 0) return callback({ type: "user_dead" }, null);

      // 2. Get Boss Stats
      const bossQuery = "SELECT * FROM Boss WHERE boss_id = ?";
      db.query(bossQuery, [bossId], (err, bossRes) => {
        if (err) return callback(err, null);
        if (bossRes.length === 0) return callback({ type: "boss_not_found" }, null);
        
        const boss = bossRes[0];
        if (boss.current_hp <= 0) return callback({ type: "boss_dead" }, null);

        // --- CALCULATION START ---
        
        // A. Player Attacks Boss
        const playerDamage = 10 + parseInt(user.weapon_dmg); // Base 10 + Weapons
        const newBossHp = Math.max(0, boss.current_hp - playerDamage);

        // B. Boss Attacks Player (if Boss survived)
        let bossDamage = 0;
        let actualPlayerDamageTaken = 0;
        let newUserHp = user.current_hp;

        if (newBossHp > 0) {
          const totalDefense = user.defense + parseInt(user.armor_def);
          bossDamage = boss.attack_power;
          // Damage formula: Boss Atk - User Def (min 1 damage)
          actualPlayerDamageTaken = Math.max(1, bossDamage - totalDefense);
          newUserHp = Math.max(0, user.current_hp - actualPlayerDamageTaken);
        }

        // --- UPDATE DATABASE ---
        
        // Update Boss HP
        db.query("UPDATE Boss SET current_hp = ? WHERE boss_id = ?", [newBossHp, bossId], (err) => {
          if (err) return callback(err, null);

          // Update User HP
          db.query("UPDATE User SET current_hp = ? WHERE user_id = ?", [newUserHp, userId], (err) => {
            if (err) return callback(err, null);

            // Return Battle Log
            callback(null, {
              turn_summary: {
                player_attack: {
                  damage_dealt: playerDamage,
                  boss_hp_remaining: newBossHp
                },
                boss_counter_attack: {
                  raw_damage: bossDamage,
                  mitigated_by_armor: user.armor_def,
                  damage_taken: actualPlayerDamageTaken,
                  player_hp_remaining: newUserHp
                }
              },
              status: newUserHp === 0 ? "YOU DIED" : newBossHp === 0 ? "VICTORY" : "BATTLE CONTINUES"
            });
          });
        });
      });
    });
  },

  // --- USE POTION ---
  heal: (userId, callback) => {
    // 1. Find a potion in inventory
    const findPotion = `
      SELECT ui.inventory_id, s.power_value 
      FROM UserInventory ui
      JOIN ShopItem s ON ui.item_id = s.item_id
      WHERE ui.user_id = ? AND s.type = 'potion'
      LIMIT 1
    `;

    db.query(findPotion, [userId], (err, results) => {
      if (err) return callback(err, null);
      if (results.length === 0) return callback({ type: "no_potion" }, null);

      const potion = results[0];

      // 2. Consume Potion (Delete form inventory)
      db.query("DELETE FROM UserInventory WHERE inventory_id = ?", [potion.inventory_id], (err) => {
        if (err) return callback(err, null);

        // 3. Heal User
        db.query("UPDATE User SET current_hp = LEAST(max_hp, current_hp + ?) WHERE user_id = ?", [potion.power_value, userId], (err) => {
            if (err) return callback(err, null);
            
            callback(null, {
                message: "Potion used!",
                healed_amount: potion.power_value,
                inventory_update: "Potion removed"
            });
        });
      });
    });
  }
};

module.exports = Boss;