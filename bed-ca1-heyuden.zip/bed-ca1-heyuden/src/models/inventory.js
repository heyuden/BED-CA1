const db = require("../services/db");

const Inventory = {
  findByUserId: (userId, callback) => {
    const query = `
      SELECT ui.inventory_id, s.name, s.type, s.power_value 
      FROM UserInventory ui
      JOIN ShopItem s ON ui.item_id = s.item_id
      WHERE ui.user_id = ?
    `;
    
    db.query(query, [userId], (err, results) => {
      if (err) {
        return callback(err, null);
      }
      callback(null, results);
    });
  }
};

module.exports = Inventory;