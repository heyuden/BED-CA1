const db = require("../services/db");

const ShopItem = {
  // Get all shop items
  findAll: (callback) => {
    const query = "SELECT * FROM ShopItem";
    db.query(query, callback);
  },

  // Purchase Item (Using Points)
  purchase: (userId, itemId, callback) => {
    // 1. Get Item Cost
    const itemQuery = "SELECT cost, name FROM ShopItem WHERE item_id = ?";
    db.query(itemQuery, [itemId], (err, items) => {
      if (err) return callback(err, null);
      if (items.length === 0) return callback({ type: "item_not_found" }, null);

      const item = items[0];

      // 2. Check User Points
      const userQuery = "SELECT points FROM User WHERE user_id = ?";
      db.query(userQuery, [userId], (err, users) => {
        if (err) return callback(err, null);
        if (users.length === 0) return callback({ type: "user_not_found" }, null);

        const currentPoints = users[0].points;

        // Check if user has enough points
        if (currentPoints < item.cost) {
          return callback({ type: "insufficient_funds" }, null);
        }

        // 3. Deduct Points
        const deductQuery = "UPDATE User SET points = points - ? WHERE user_id = ?";
        db.query(deductQuery, [item.cost, userId], (err) => {
          if (err) return callback(err, null);

          // 4. Add to Inventory
          const inventoryQuery = "INSERT INTO UserInventory (user_id, item_id) VALUES (?, ?)";
          db.query(inventoryQuery, [userId, itemId], (err, result) => {
            if (err) return callback(err, null);
            
            callback(null, {
              message: `Successfully purchased ${item.name}`,
              points_remaining: currentPoints - item.cost,
              inventory_id: result.insertId
            });
          });
        });
      });
    });
  }
};

module.exports = ShopItem;