const db = require("../services/db");

// Model for User operations
const User = {
  // Create a new user
  create: (username, callback) => {
    const query = "INSERT INTO User (username) VALUES (?)";
    db.query(query, [username], (err, result) => {
      if (err) {
        // Handle duplicate username error
        if (err.code === "ER_DUP_ENTRY" || err.code === "ER_DUP_KEY") {
          return callback({ type: "conflict" }, null);
        }
        return callback(err, null);
      }
      // Return the new user's ID and default info
      callback(null, {
        user_id: result.insertId,
        username: username,
        points: 0,
      });
    });
  },

  // Get all users
  findAll: (callback) => {
    const query = "SELECT user_id, username, points FROM User";
    db.query(query, (err, results) => {
      if (err) {
        return callback(err, null);
      }
      callback(null, results);
    });
  },

  // Find a user by ID
  findById: (userId, callback) => {
    const query =
      "SELECT user_id, username, points FROM User WHERE user_id = ?";
    db.query(query, [userId], (err, results) => {
      if (err) {
        return callback(err, null);
      }
      // Check if user was found
      if (results.length === 0) {
        return callback({ type: "not_found" }, null);
      }
      callback(null, results[0]);
    });
  },

  // Find a user by username (for checking duplicates)
  findByUsername: (username, callback) => {
    const query =
      "SELECT user_id, username, points FROM User WHERE username = ?";
    db.query(query, [username], (err, results) => {
      if (err) {
        return callback(err, null);
      }
      callback(null, results[0]);
    });
  },

  // Update a user
  update: (userId, data, callback) => {
    const { username, points } = data;
    const query = "UPDATE User SET username = ?, points = ? WHERE user_id = ?";

    db.query(query, [username, points, userId], (err, result) => {
      if (err) {
        // Handle duplicate username error on update
        if (err.code === "ER_DUP_ENTRY" || err.code === "ER_DUP_KEY") {
          return callback({ type: "conflict" }, null);
        }
        return callback(err, null);
      }
      // Check if any row was actually updated
      if (result.affectedRows === 0) {
        return callback({ type: "not_found" }, null);
      }
      callback(null, { user_id: userId, username: username, points: points });
    });
  },

  // Update user points (used by completion)
  updatePoints: (userId, pointsToAdd, callback) => {
    const query = "UPDATE User SET points = points + ? WHERE user_id = ?";
    db.query(query, [pointsToAdd, userId], (err, result) => {
      if (err) {
        return callback(err, null);
      }
      if (result.affectedRows === 0) {
        return callback({ type: "not_found" }, null);
      }
      callback(null, result);
    });
  },
};

module.exports = User;