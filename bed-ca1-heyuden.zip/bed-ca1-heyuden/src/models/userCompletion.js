const db = require("../services/db");

const UserCompletion = {
  // UPDATED: Award Points Only
  awardPoints: (userId, pointsToAward, callback) => {
    // Update points and XP (assuming 1 point = 1 XP for simplicity, or just points)
    const query = "UPDATE User SET points = points + ?, xp = xp + ? WHERE user_id = ?";
    
    // Using pointsToAward for both Points and XP increase
    db.query(query, [pointsToAward, pointsToAward, userId], (err, result) => {
      if (err) return callback(err, null);
      if (result.affectedRows === 0) return callback({ type: "not_found" }, null);
      callback(null, result);
    });
  },
  
  // Re-adding the other required functions to make this copy-paste safe:
  create: (data, callback) => {
    const { challenge_id, user_id, details } = data;
    const query = "INSERT INTO UserCompletion (challenge_id, user_id, details) VALUES (?, ?, ?)";
    db.query(query, [challenge_id, user_id, details], (err, result) => {
      if (err) {
        if (err.code === "ER_NO_REFERENCED_ROW_2") return callback({ type: "not_found" }, null);
        return callback(err, null);
      }
      callback(null, result);
    });
  },
  
  findByChallengeId: (challengeId, callback) => {
    const query = "SELECT user_id, details FROM UserCompletion WHERE challenge_id = ?";
    db.query(query, [challengeId], (err, results) => {
        if (err) return callback(err, null);
        if (results.length === 0) return callback(null, []);
        callback(null, results);
    });
  },

  deleteByChallengeId: (challengeId, callback) => {
    const query = "DELETE FROM UserCompletion WHERE challenge_id = ?";
    db.query(query, [challengeId], (err, result) => {
        if (err) return callback(err, null);
        callback(null, result);
    });
  },

  findById: (completeId, callback) => {
    const query = "SELECT * FROM UserCompletion WHERE completion_id = ?";
    db.query(query, [completeId], (err, results) => {
        if (err) return callback(err, null);
        if (results.length === 0) return callback({ type: "not_found" }, null);
        callback(null, results[0]);
    });
  }
};

module.exports = UserCompletion;