const db = require("../services/db");

const WellnessChallenge = {
  // Create a new challenge
  create: (data, callback) => {
    const { creator_id, description, points } = data;
    const query =
      "INSERT INTO WellnessChallenge (creator_id, description, points) VALUES (?, ?, ?)";

    db.query(query, [creator_id, description, points], (err, result) => {
      if (err) {
        return callback(err, null);
      }
      callback(null, {
        challenge_id: result.insertId,
        challenge: description, // Match response field from brief
        creator_id: creator_id,
        points: points,
      });
    });
  },

  // Get all challenges
  findAll: (callback) => {
    // Renaming description to 'challenge' to match sample response
    const query =
      "SELECT challenge_id, creator_id, description as challenge, points FROM WellnessChallenge";
    db.query(query, (err, results) => {
      if (err) {
        return callback(err, null);
      }
      callback(null, results);
    });
  },

  // Find a challenge by ID
  findById: (challengeId, callback) => {
    const query =
      "SELECT challenge_id, creator_id, description as challenge, points FROM WellnessChallenge WHERE challenge_id = ?";
    db.query(query, [challengeId], (err, results) => {
      if (err) {
        return callback(err, null);
      }
      if (results.length === 0) {
        return callback({ type: "not_found" }, null);
      }
      callback(null, results[0]);
    });
  },

  // Update a challenge
  update: (challengeId, data, callback) => {
    const { description, points, creator_id } = data;
    const query =
      "UPDATE WellnessChallenge SET description = ?, points = ? WHERE challenge_id = ? AND creator_id = ?";

    db.query(
      query,
      [description, points, challengeId, creator_id],
      (err, result) => {
        if (err) {
          return callback(err, null);
        }
        if (result.affectedRows === 0) {
          // Check if it exists first to differentiate not found vs forbidden
          WellnessChallenge.findById(challengeId, (findErr, challenge) => {
            if (findErr) return callback(findErr, null); // DB error
            if (!challenge) return callback({ type: "not_found" }, null); // Not found
            // Exists, but creator_id didn't match
            return callback({ type: "forbidden" }, null);
          });
        } else {
          callback(null, {
            challenge_id: challengeId,
            challenge: description,
            creator_id: creator_id,
            points: points,
          });
        }
      }
    );
  },

  // Delete a challenge
  delete: (challengeId, callback) => {
    const query = "DELETE FROM WellnessChallenge WHERE challenge_id = ?";
    db.query(query, [challengeId], (err, result) => {
      if (err) {
        return callback(err, null);
      }
      if (result.affectedRows === 0) {
        return callback({ type: "not_found" }, null);
      }
      callback(null, result);
    });
  },
};

module.exports = WellnessChallenge;