const express = require('express');
const router = express.Router();
const controller = require('../controllers/bossController');

router.get('/:boss_id', controller.getBossInfo);
router.post('/:boss_id/fight', controller.startBossFight);
router.post('/heal', controller.usePotion); 

module.exports = router;