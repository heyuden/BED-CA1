const express = require('express');
const router = express.Router();
const controller = require('../controllers/challengeController');
const completionController = require('../controllers/completionController');

// Challenge CRUD
router.get('/', controller.getAllChallenges);
router.post('/', controller.createNewChallenge);
router.put('/:challenge_id', controller.updateChallengeById);
router.delete('/:challenge_id', controller.deleteChallengeById);

// Completion Endpoints
router.post('/:challenge_id/complete', completionController.createCompletion);

// *** FIX IS HERE: Use 'getCompletionsByChallengeId' ***
router.get('/:challenge_id/users', completionController.getCompletionsByChallengeId); 

module.exports = router;