//zhujhonglu.24@ichat.sp.edu.sg P2411598 DIT/FT/1B/04
const express = require('express');
const router = express.Router();

const userRoutes = require('./userRoutes');
router.use('/users', userRoutes);

const challengeRoutes = require('./challengeRoutes');
router.use("/challenges", challengeRoutes);

const shopRoutes = require("./shopRoutes");
router.use("/shop", shopRoutes);

const bossRoutes = require('./bossRoutes');
router.use('/boss', bossRoutes);

const inventoryRoutes = require('./inventoryRoutes'); 
router.use('/inventory', inventoryRoutes); 

module.exports = router;