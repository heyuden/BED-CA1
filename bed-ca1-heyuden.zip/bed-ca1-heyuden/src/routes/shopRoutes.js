const express = require('express');
const router = express.Router();
const controller = require('../controllers/shopController');

router.get('/', controller.getAllItems);
router.post('/buy', controller.buyItem);


module.exports = router;