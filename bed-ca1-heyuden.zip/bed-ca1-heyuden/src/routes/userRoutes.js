//zhujhonglu.24@ichat.sp.edu.sg P2411598 DIT/FT/1B/04
const express = require("express");
const router = express.Router();
const userController = require("../controllers/userController");

// POST /users - Create a new user
router.post("/", userController.createNewUser);

// GET /users - Retrieve a list of all users
router.get("/", userController.getAllUsers);

// GET /users/:user_id - Retrieve a specific user by ID
router.get("/:user_id", userController.getUserById);

// PUT /users/:user_id - Update user details
router.put("/:user_id", userController.updateUserById);

module.exports = router;
