//zhujhonglu.24@ichat.sp.edu.sg P2411598 DIT/FT/1B/04
require('dotenv').config(); // MUST be at the very top
const mysql = require("mysql2");

// Create a connection pool
// This is more efficient than creating individual connections
const pool = mysql.createPool({
  connectionLimit: 10, // Max number of connections
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  port: process.env.DB_PORT,
  multipleStatements: true, 
});

// Test the database connection
pool.getConnection((err, connection) => {
  if (err) {
    console.error("Error connecting to the database:");
    if (err.code === "PROTOCOL_CONNECTION_LOST") {
      console.error("Database connection was closed.");
    }
    if (err.code === "ER_CON_COUNT_ERROR") {
      console.error("Database has too many connections.");
    }
    if (err.code === "ECONNREFUSED") {
      console.error("Database connection was refused.");
    }
    return;
  }

  if (connection) {
    connection.release(); // Release the connection back to the pool
    console.log("Successfully connected to the MySQL database.");
  }
});

// Export the pool to be used by models
module.exports = pool;
